DATASET FOLDER - put your downloaded images here
================================================

Each sub-folder is one hazard class. Put the images directly inside (any sub-folders are fine):

  dataset\pothole\        photos of potholes
  dataset\ice_wet\        black ice, snow, wet slippery roads
  dataset\debris\         objects / debris lying on the road
  dataset\waterlogging\   flooded / water-covered roads
  dataset\no_hazard\      normal, clear, dry roads

Formats: .jpg .jpeg .png .bmp .webp.   Aim for 500-1500 images per class (min 10, 200+ recommended).
You do NOT need all 5 classes - training uses every folder that contains images (at least 2).

WHAT TO DOWNLOAD
----------------
1) POTHOLES  (+ some no_hazard)
   Kaggle -> "Pothole Image Dataset" by sachinpatel21  (kaggle.com/datasets/sachinpatel21/pothole-image-dataset)
   Any Kaggle pothole set with "Normal"/"Plain" and "Pothole" folders also works.

2) ICE / WET, WATERLOGGING, NO_HAZARD
   RSCD - Road Surface Classification Dataset (Tsinghua Univ.)
   github.com/ztsrxh/RSCD-Road_Surface_Classification_Dataset  (follow the download link on that page)
     ice, fresh-snow, melted-snow, wet-*  -> ice_wet
     water-*                              -> waterlogging
     dry-*                                -> no_hazard
   It is huge (~1 million images). You only need the TRAIN folder, and the helper script copies
   just ~1000 per class for you.

3) DEBRIS  (optional)
   Search for a road-debris / road-obstacle image dataset, e.g. the "Lost and Found" road obstacle
   dataset or Kaggle "road debris / road obstacles". If you skip it, the model trains on 4 classes.

EASY WAY: after downloading + extracting, open 2a_prepare_dataset.bat in Notepad, type the folder
paths at the top, save, double-click it. It copies and sorts everything into the folders here.
(Or copy the images by hand.)

ENVIRONMENT DATA
----------------
Do nothing. On the first training run, "environment.csv" is created here automatically
(simulated weather / visibility / temperature / light sequences). If you have real readings, replace
that file using the same columns.

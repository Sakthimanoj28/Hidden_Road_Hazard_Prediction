@echo off
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3.10, 3.11 or 3.12 from python.org
  echo and tick "Add python.exe to PATH" during installation. Then run this file again.
  pause
  exit /b 1
)
if not exist "venv" python -m venv venv
call "venv\Scripts\activate.bat"
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Setup finished. Next: put the dataset in the "dataset" folder (see README.md), then run 2_check_dataset.bat
pause

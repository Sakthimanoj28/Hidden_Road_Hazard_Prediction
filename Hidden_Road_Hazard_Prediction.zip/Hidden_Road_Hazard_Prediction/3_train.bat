@echo off
cd /d "%~dp0"
if exist "venv\Scripts\activate.bat" call "venv\Scripts\activate.bat"
rem Trains vision-only, environment-only and fusion models, then compares them.
python src\train.py %*
pause

@echo off
cd /d "%~dp0"
if exist "venv\Scripts\activate.bat" call "venv\Scripts\activate.bat"
rem Faster settings for laptops without an NVIDIA GPU.
python src\train.py --max_per_class 600 --img_size 160 --epochs 8
pause

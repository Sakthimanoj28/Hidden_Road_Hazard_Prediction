@echo off
cd /d "%~dp0"
if exist "venv\Scripts\activate.bat" call "venv\Scripts\activate.bat"
rem ------------------------------------------------------------------
rem  EDIT the folders below to where you downloaded/extracted each dataset.
rem  Leave a line empty if you do not have that dataset.
rem  (Do NOT put quotes around the paths.)
rem ------------------------------------------------------------------
set POTHOLE=
set RSCD=
set DEBRIS=
set NORMAL=
set PER_CLASS=1000

set ARGS=--per_class %PER_CLASS%
if not "%POTHOLE%"=="" set ARGS=%ARGS% --pothole_dir "%POTHOLE%"
if not "%RSCD%"=="" set ARGS=%ARGS% --rscd_dir "%RSCD%"
if not "%DEBRIS%"=="" set ARGS=%ARGS% --debris_dir "%DEBRIS%"
if not "%NORMAL%"=="" set ARGS=%ARGS% --normal_dir "%NORMAL%"
python src\prepare_dataset.py %ARGS%
pause

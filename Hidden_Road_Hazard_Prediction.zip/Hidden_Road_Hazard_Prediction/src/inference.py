"""Load a trained model and predict hazard type + risk level for one image + weather reading."""
from pathlib import Path

import numpy as np
import torch
from PIL import Image

import config
import env_data
from config import CLASS_LABELS, RISK_LEVELS, SEVERITY, WEATHER, ROAD_TYPES, SEASONS, SEQ_LEN
from dataset import get_transforms
from model import HazardNet

DEFAULT_ENV = dict(weather="clear", road_type="urban", season="monsoon",
                   temperature=28.0, humidity=60.0, rain=0.0, visibility=10.0, light=0.9)


def get_device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def available_modes(out_dir=config.OUT_DIR):
    return [m for m in ("fusion", "vision", "env") if (Path(out_dir) / m / "best.pt").exists()]


def load_model(mode="fusion", out_dir=config.OUT_DIR, device=None):
    device = device or get_device()
    path = Path(out_dir) / mode / "best.pt"
    if not path.exists():
        raise FileNotFoundError(f"{path} not found. Train first (3_train.bat).")
    ck = torch.load(path, map_location=device)
    model = HazardNet(len(ck["classes"]), ck["mode"], pretrained=False, rnn=ck["rnn"])
    model.load_state_dict(ck["state_dict"])
    return model.to(device).eval(), ck


def _heatmap(attn, image, size):
    import matplotlib
    a = attn[0, 0].cpu().numpy()
    a = (a - a.min()) / (a.max() - a.min() + 1e-8)
    a = np.asarray(Image.fromarray((a * 255).astype(np.uint8)).resize(size, Image.BILINEAR)) / 255.0
    color = (matplotlib.colormaps["jet"](a)[..., :3] * 255).astype(np.uint8)
    base = np.asarray(image.convert("RGB").resize(size))
    return Image.fromarray((0.6 * base + 0.4 * color).astype(np.uint8))


def predict(model, ck, image, env=None, device=None):
    device = device or get_device()
    env = {**DEFAULT_ENV, **(env or {})}
    classes = ck["classes"]
    img = get_transforms(ck["img_size"], False)(image.convert("RGB")).unsqueeze(0).to(device)
    raw = np.array([[env["temperature"], env["humidity"], env["rain"],
                     env["visibility"], env["light"]]] * SEQ_LEN, dtype=np.float32)
    num = torch.from_numpy(env_data.encode_numeric(raw)).unsqueeze(0).to(device)
    cat = torch.tensor([[WEATHER.index(env["weather"]), ROAD_TYPES.index(env["road_type"]),
                         SEASONS.index(env["season"])]], dtype=torch.long, device=device)
    with torch.no_grad():
        lh, lr, attn = model(img, num, cat)
    probs = torch.softmax(lh, 1)[0].cpu().numpy()
    rprobs = torch.softmax(lr, 1)[0].cpu().numpy()
    top = int(probs.argmax())
    cls = classes[top]
    level = RISK_LEVELS[int(rprobs.argmax())]
    adv = env_data.adversity(raw[-1])
    score = float(sum(p * SEVERITY[c] for p, c in zip(probs, classes)) * (0.6 + 0.4 * adv))
    if cls == "no_hazard":
        msg = f"Road ahead looks clear. Risk level: {level.upper()}."
    else:
        msg = (f"WARNING: {CLASS_LABELS[cls]} likely ahead. Risk level: {level.upper()}. "
               "Reduce speed and stay alert.")
    heat = _heatmap(attn, image, image.size) if attn is not None else None
    return {"hazard": cls, "hazard_label": CLASS_LABELS[cls], "confidence": float(probs[top]),
            "probabilities": {CLASS_LABELS[c]: float(p) for c, p in zip(classes, probs)},
            "risk_level": level, "risk_probs": dict(zip(RISK_LEVELS, map(float, rprobs))),
            "risk_score": score, "message": msg, "attention": heat}

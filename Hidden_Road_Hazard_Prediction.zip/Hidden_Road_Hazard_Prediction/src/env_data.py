"""Environmental data: simulation, loading, encoding and risk-level rules.

No public dataset pairs road-hazard images with weather sequences, so
`environment.csv` is generated automatically (class-conditioned + 35% random
noise). If you have REAL readings, replace dataset/environment.csv using the
same columns and the project will use them instead.
"""
import hashlib
import numpy as np
import pandas as pd

from config import (WEATHER, ROAD_TYPES, SEASONS, NUM_FEATS, SEQ_LEN,
                    SEVERITY, RISK_LEVELS)

NOISE = 0.35  # share of weather drawn at random -> prevents trivial leakage

#            clear  rain   fog   snow  overcast
WEATHER_PRIOR = {
    "pothole":      [0.30, 0.35, 0.03, 0.00, 0.32],
    "ice_wet":      [0.10, 0.30, 0.15, 0.30, 0.15],
    "debris":       [0.40, 0.20, 0.05, 0.00, 0.35],
    "waterlogging": [0.05, 0.75, 0.05, 0.00, 0.15],
    "no_hazard":    [0.65, 0.05, 0.03, 0.00, 0.27],
}
_BASE = {  # per weather: temp, humidity, rain mm/h, visibility km, light factor
    "clear":    (27, 50, 0.0, 10.0, 1.00),
    "rain":     (22, 90, 8.0, 4.0, 0.60),
    "fog":      (14, 95, 0.5, 0.6, 0.50),
    "snow":     (-2, 85, 1.0, 2.0, 0.60),
    "overcast": (20, 70, 0.5, 8.0, 0.75),
}
_SEASON_OFFSET = {"summer": 6, "monsoon": 0, "autumn": -2, "winter": -8}


def num_cols():
    return [f"{f}_{t}" for f in NUM_FEATS for t in range(SEQ_LEN)]


def _rng(key: str):
    return np.random.default_rng(int(hashlib.md5(key.encode()).hexdigest()[:8], 16))


def simulate_row(rel_path: str, cls: str) -> dict:
    rng = _rng(rel_path)
    prior = (1 - NOISE) * np.array(WEATHER_PRIOR[cls]) + NOISE * np.full(len(WEATHER), 1 / len(WEATHER))
    weather = WEATHER[rng.choice(len(WEATHER), p=prior / prior.sum())]
    road = ROAD_TYPES[rng.integers(len(ROAD_TYPES))]
    season = "winter" if weather == "snow" else SEASONS[rng.integers(len(SEASONS))]

    t0, h0, r0, v0, l0 = _BASE[weather]
    temp = t0 + (0 if weather == "snow" else _SEASON_OFFSET[season]) + rng.normal(0, 3)
    if cls == "ice_wet":
        temp -= 5
    rain = r0 + (10 if cls == "waterlogging" and weather == "rain" else 0) + rng.exponential(1.0)
    hum = h0 + rng.normal(0, 4)
    vis = max(0.1, v0 + rng.normal(0, 0.8))
    light = l0 * rng.choice([0.12, 0.4, 0.95], p=[0.2, 0.2, 0.6])

    t = np.arange(SEQ_LEN) / (SEQ_LEN - 1)
    ramp = 0.5 + 0.5 * t if weather in ("rain", "snow") else np.ones(SEQ_LEN)
    seq = {
        "temperature": temp + rng.normal(0, 0.4, SEQ_LEN) + rng.normal(0, 0.3) * (t - 1) * 3,
        "humidity": np.clip(hum * (0.85 + 0.15 * ramp) + rng.normal(0, 2, SEQ_LEN), 20, 100),
        "rain": np.clip(rain * ramp + np.abs(rng.normal(0, 0.4, SEQ_LEN)), 0, 60),
        "visibility": np.clip(vis * (1.3 - 0.3 * ramp) + rng.normal(0, 0.2, SEQ_LEN), 0.05, 15),
        "light": np.clip(light + rng.normal(0, 0.03, SEQ_LEN), 0, 1),
    }
    row = {"weather": weather, "road_type": road, "season": season}
    for f in NUM_FEATS:
        for i in range(SEQ_LEN):
            row[f"{f}_{i}"] = round(float(seq[f][i]), 3)
    return row


def ensure_environment_csv(data_dir, rel_paths, labels):
    """Create dataset/environment.csv, or fill in rows missing from it."""
    path = data_dir / "environment.csv"
    existing = pd.read_csv(path) if path.exists() else pd.DataFrame(columns=["filename"])
    have = set(existing["filename"].astype(str))
    new_rows = []
    for rel, lab in zip(rel_paths, labels):
        if rel not in have:
            r = simulate_row(rel, lab)
            r.update(filename=rel, label=lab)
            new_rows.append(r)
    if new_rows:
        head = ["filename", "label", "weather", "road_type", "season"] + num_cols()
        out = pd.concat([existing, pd.DataFrame(new_rows)], ignore_index=True)
        out = out[[c for c in head if c in out.columns] + [c for c in out.columns if c not in head]]
        out.to_csv(path, index=False)
        kind = "created" if existing.empty else "updated"
        print(f"[env] {kind} {path.name}: simulated environment for {len(new_rows)} images")
    return pd.read_csv(path).set_index("filename")


def encode_numeric(arr):
    """arr [..., T, 5] raw units -> roughly 0-1 scaled network input."""
    a = np.asarray(arr, dtype=np.float32).copy()
    a[..., 0] = (a[..., 0] - 20.0) / 15.0                     # temperature
    a[..., 1] = a[..., 1] / 100.0                             # humidity
    a[..., 2] = np.log1p(np.clip(a[..., 2], 0, None)) / 3.0   # rain
    a[..., 3] = a[..., 3] / 10.0                              # visibility
    return a                                                  # light already 0-1


def adversity(last):
    """Environmental danger 0-1 from the latest reading [temp, hum, rain, vis, light]."""
    temp, _, rain, vis, light = [float(x) for x in last]
    parts = [min(rain / 15, 1), 1 - min(vis / 10, 1), 1 - min(max(light, 0), 1),
             min(max((5 - temp) / 10, 0), 1)]
    return float(np.mean(parts))


def risk_score(cls, last):
    return SEVERITY[cls] * (0.6 + 0.4 * adversity(last))


def risk_level_idx(cls, last):
    s = risk_score(cls, last)
    return 0 if s < 0.35 else (1 if s < 0.60 else 2)


def level_name(i):
    return RISK_LEVELS[i]

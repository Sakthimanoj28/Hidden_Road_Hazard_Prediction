"""Web demo (opens in your browser):  python src/app.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gradio as gr
from config import WEATHER, ROAD_TYPES, SEASONS
from inference import load_model, predict, available_modes, DEFAULT_ENV, get_device

_cache, DEV = {}, get_device()


def run(image, mode, weather, road, season, temp, hum, rain, vis, light):
    if image is None:
        return {}, "Please upload a road image.", None
    if mode not in _cache:
        _cache[mode] = load_model(mode, device=DEV)
    model, ck = _cache[mode]
    r = predict(model, ck, image, dict(weather=weather, road_type=road, season=season,
                                       temperature=temp, humidity=hum, rain=rain,
                                       visibility=vis, light=light), DEV)
    text = (f"{r['message']}\nRisk score: {r['risk_score']:.0%}  |  "
            f"Confidence: {r['confidence']:.1%}")
    return r["probabilities"], text, r["attention"]


def main():
    modes = available_modes()
    if not modes:
        raise SystemExit("No trained model found in outputs/. Run 3_train.bat first.")
    d = DEFAULT_ENV
    demo = gr.Interface(
        fn=run,
        inputs=[
            gr.Image(type="pil", label="Road image"),
            gr.Dropdown(modes, value=modes[0], label="Model"),
            gr.Dropdown(WEATHER, value=d["weather"], label="Weather"),
            gr.Dropdown(ROAD_TYPES, value=d["road_type"], label="Road type"),
            gr.Dropdown(SEASONS, value=d["season"], label="Season"),
            gr.Slider(-10, 50, value=d["temperature"], label="Temperature (deg C)"),
            gr.Slider(10, 100, value=d["humidity"], label="Humidity (%)"),
            gr.Slider(0, 50, value=d["rain"], label="Rain (mm/hour)"),
            gr.Slider(0.1, 15, value=d["visibility"], label="Visibility (km)"),
            gr.Slider(0, 1, value=d["light"], label="Light level (0 dark - 1 bright)"),
        ],
        outputs=[gr.Label(label="Hazard type probabilities"),
                 gr.Textbox(label="Warning / risk level"),
                 gr.Image(label="Where the model looked (attention)")],
        title="Hidden Road Hazard Prediction",
        description="Upload a road image and enter the current weather to predict the hazard and risk level.",
    )
    demo.launch(inbrowser=True)


if __name__ == "__main__":
    main()

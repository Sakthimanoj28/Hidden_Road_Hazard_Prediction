"""Check your dataset folders before training:  python src/check_dataset.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config
from config import ALL_CLASSES, CLASS_LABELS
from data_utils import scan_images, class_summary


def main():
    d = Path(sys.argv[1]) if len(sys.argv) > 1 else config.DATA_DIR
    print(f"Checking: {d}\n")
    df, classes = scan_images(d, verify=True)
    counts = class_summary(df, classes)
    for c in ALL_CLASSES:
        n = counts.get(c, 0)
        flag = "OK     " if n >= 200 else ("LOW    " if n >= 10 else "MISSING")
        print(f"  [{flag}] {c:<14} {n:>6} images   ({CLASS_LABELS[c]})")
    print(f"\n  Total usable images: {len(df)}")
    if len(classes) < 2:
        print("\n  -> Add images to at least 2 class folders (see dataset/README.txt).")
    elif len(classes) < len(ALL_CLASSES):
        print("\n  Training will still work using the classes that have images.")
    else:
        print("\n  Dataset looks good. Next: 3_train.bat")
    print("  (Aim for 200+ images per class; 500-1500 gives the best results.)")


if __name__ == "__main__":
    main()

"""Dataset scanning, splitting and table building (no torch needed)."""
import numpy as np
import pandas as pd
from PIL import Image
from sklearn.model_selection import train_test_split

from config import (ALL_CLASSES, IMG_EXT, WEATHER, ROAD_TYPES, SEASONS,
                    NUM_FEATS, SEQ_LEN, SEED)
import env_data


def scan_images(data_dir, verify=True):
    """Return (DataFrame[rel,label], classes) for class folders that hold images."""
    rows, bad = [], []
    for cls in ALL_CLASSES:
        folder = data_dir / cls
        if not folder.is_dir():
            continue
        for p in sorted(folder.rglob("*")):
            if p.suffix.lower() not in IMG_EXT:
                continue
            if verify:
                try:
                    with Image.open(p) as im:
                        im.verify()
                except Exception:
                    bad.append(str(p))
                    continue
            rows.append({"rel": f"{cls}/{p.relative_to(folder).as_posix()}", "label": cls})
    if bad:
        (data_dir / "bad_files.txt").write_text("\n".join(bad))
        print(f"[data] skipped {len(bad)} unreadable images (listed in bad_files.txt)")
    df = pd.DataFrame(rows, columns=["rel", "label"])
    classes = [c for c in ALL_CLASSES if (df["label"] == c).any()]
    return df, classes


def class_summary(df, classes):
    return {c: int((df["label"] == c).sum()) for c in classes}


def build_tables(data_dir, verify=True):
    """Scan images, attach environment + risk labels. Returns df, X_num(raw units), classes."""
    df, classes = scan_images(data_dir, verify)
    if len(classes) < 2:
        raise SystemExit(
            "\nNot enough data: found images for %d class(es) in %s\n"
            "Put images into at least 2 class folders (see dataset/README.txt),\n"
            "or run  python src/smoke_test.py  to test the pipeline with fake data.\n"
            % (len(classes), data_dir))
    counts = class_summary(df, classes)
    small = [c for c, n in counts.items() if n < 10]
    if small:
        raise SystemExit(f"\nClass folder(s) {small} have fewer than 10 images. "
                         "Add more images or remove the folder.\n")
    env = env_data.ensure_environment_csv(data_dir, df["rel"].tolist(), df["label"].tolist())
    env = env.loc[df["rel"]].reset_index()

    X = np.stack([env[[f"{f}_{t}" for t in range(SEQ_LEN)]].values for f in NUM_FEATS],
                 axis=-1).astype(np.float32)             # [N, T, 5] raw units
    df = df.reset_index(drop=True)
    df["label_idx"] = df["label"].map({c: i for i, c in enumerate(classes)})
    df["weather_idx"] = env["weather"].map({w: i for i, w in enumerate(WEATHER)}).values
    df["road_idx"] = env["road_type"].map({w: i for i, w in enumerate(ROAD_TYPES)}).values
    df["season_idx"] = env["season"].map({w: i for i, w in enumerate(SEASONS)}).values
    if df[["weather_idx", "road_idx", "season_idx"]].isna().any().any():
        raise SystemExit("environment.csv has weather/road_type/season values outside the "
                         f"allowed lists: {WEATHER}, {ROAD_TYPES}, {SEASONS}")
    df["risk_idx"] = [env_data.risk_level_idx(l, X[i, -1]) for i, l in enumerate(df["label"])]
    return df, X, classes


def split_indices(df, seed=SEED):
    idx = np.arange(len(df))
    tr, rest = train_test_split(idx, test_size=0.30, stratify=df["label_idx"], random_state=seed)
    va, te = train_test_split(rest, test_size=0.50, stratify=df["label_idx"].values[rest],
                              random_state=seed)
    return tr, va, te

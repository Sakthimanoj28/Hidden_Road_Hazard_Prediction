"""PyTorch dataset + image transforms (incl. simulated rain / fog augmentation)."""
import random
import numpy as np
import torch
from PIL import Image, ImageDraw
from torch.utils.data import Dataset
from torchvision import transforms as T

import env_data

MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


class SimulatedWeather:
    """Randomly adds fog and/or rain streaks to a PIL image (training only)."""

    def __init__(self, p_fog=0.25, p_rain=0.25):
        self.p_fog, self.p_rain = p_fog, p_rain

    def __call__(self, img):
        img = img.convert("RGB")
        if random.random() < self.p_fog:
            fog = Image.new("RGB", img.size, (200, 200, 205))
            img = Image.blend(img, fog, random.uniform(0.15, 0.45))
        if random.random() < self.p_rain:
            w, h = img.size
            layer = img.copy()
            d = ImageDraw.Draw(layer)
            for _ in range(int(w * h / 900)):
                x, y = random.randint(0, w), random.randint(0, h)
                ln = random.randint(8, 18)
                d.line([(x, y), (x - 2, y + ln)], fill=(220, 220, 230), width=1)
            img = Image.blend(img, layer, 0.6)
        return img


def get_transforms(img_size=224, train=True):
    if train:
        return T.Compose([
            T.RandomResizedCrop(img_size, scale=(0.7, 1.0)),
            T.RandomHorizontalFlip(),
            T.RandomRotation(8),
            T.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2),
            SimulatedWeather(),
            T.ToTensor(),
            T.Normalize(MEAN, STD),
        ])
    return T.Compose([T.Resize((img_size, img_size)), T.ToTensor(), T.Normalize(MEAN, STD)])


class HazardDataset(Dataset):
    def __init__(self, df, X_raw, data_dir, transform, use_image=True):
        self.df = df.reset_index(drop=True)
        self.X = env_data.encode_numeric(X_raw)          # [N, T, 5]
        self.data_dir = data_dir
        self.transform = transform
        self.use_image = use_image

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        r = self.df.iloc[i]
        if self.use_image:
            img = Image.open(self.data_dir / r["rel"]).convert("RGB")
            img = self.transform(img)
        else:
            img = torch.zeros(3, 8, 8)                   # placeholder for env-only baseline
        cat = torch.tensor([r["weather_idx"], r["road_idx"], r["season_idx"]], dtype=torch.long)
        return {
            "img": img,
            "num": torch.from_numpy(self.X[i]),
            "cat": cat,
            "y": torch.tensor(int(r["label_idx"]), dtype=torch.long),
            "risk": torch.tensor(int(r["risk_idx"]), dtype=torch.long),
        }

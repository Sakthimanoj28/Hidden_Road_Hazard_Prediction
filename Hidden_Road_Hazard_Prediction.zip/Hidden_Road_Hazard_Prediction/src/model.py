"""Multimodal hazard model: CNN (ResNet18 + attention) + GRU/LSTM -> fusion -> hazard + risk."""
import torch
import torch.nn as nn
from torchvision import models

from config import WEATHER, ROAD_TYPES, SEASONS, NUM_FEATS, RISK_LEVELS


class VisualBranch(nn.Module):
    """ResNet18 backbone (ImageNet transfer learning) with spatial attention pooling."""

    def __init__(self, out_dim=256, pretrained=True, dropout=0.3):
        super().__init__()
        net = None
        if pretrained:
            try:
                net = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
            except Exception as e:  # no internet / blocked download
                print(f"[model] WARNING: could not load ImageNet weights ({type(e).__name__}); "
                      "training from scratch - accuracy will be lower.")
        if net is None:
            net = models.resnet18(weights=None)
        self.backbone = nn.Sequential(*list(net.children())[:-2])   # -> [B,512,h,w]
        self.attn = nn.Conv2d(512, 1, kernel_size=1)                # where to look
        self.proj = nn.Sequential(nn.Linear(512, out_dim), nn.BatchNorm1d(out_dim),
                                  nn.ReLU(), nn.Dropout(dropout))

    def forward(self, x):
        f = self.backbone(x)
        a = self.attn(f)                                            # [B,1,h,w]
        w = torch.softmax(a.flatten(2), dim=-1).view_as(a)
        pooled = (f * w).sum(dim=(2, 3))
        return self.proj(pooled), w


class EnvBranch(nn.Module):
    """GRU/LSTM over recent weather readings + embeddings of weather/road/season."""

    def __init__(self, out_dim=64, rnn="gru", hidden=64, dropout=0.3):
        super().__init__()
        self.emb_w = nn.Embedding(len(WEATHER), 4)
        self.emb_r = nn.Embedding(len(ROAD_TYPES), 3)
        self.emb_s = nn.Embedding(len(SEASONS), 3)
        rnn_cls = nn.GRU if rnn == "gru" else nn.LSTM
        self.rnn = rnn_cls(len(NUM_FEATS) + 10, hidden, batch_first=True)
        self.proj = nn.Sequential(nn.Linear(hidden, out_dim), nn.ReLU(), nn.Dropout(dropout))

    def forward(self, num, cat):
        e = torch.cat([self.emb_w(cat[:, 0]), self.emb_r(cat[:, 1]), self.emb_s(cat[:, 2])], dim=1)
        e = e.unsqueeze(1).expand(-1, num.size(1), -1)
        out, _ = self.rnn(torch.cat([num, e], dim=-1))
        return self.proj(out[:, -1])


class HazardNet(nn.Module):
    """mode: 'fusion' (image + environment), 'vision' (image only), 'env' (environment only)."""

    def __init__(self, n_classes, mode="fusion", pretrained=True, rnn="gru"):
        super().__init__()
        self.mode = mode
        dim = 0
        if mode in ("fusion", "vision"):
            self.visual = VisualBranch(256, pretrained)
            dim += 256
        if mode in ("fusion", "env"):
            self.env = EnvBranch(64, rnn)
            dim += 64
        self.fuse = nn.Sequential(nn.Linear(dim, 128), nn.ReLU(), nn.Dropout(0.4))
        self.hazard_head = nn.Linear(128, n_classes)          # hazard type (softmax in the loss)
        self.risk_head = nn.Linear(128, len(RISK_LEVELS))     # low / medium / high

    def forward(self, img, num, cat):
        feats, attn = [], None
        if self.mode in ("fusion", "vision"):
            v, attn = self.visual(img)
            feats.append(v)
        if self.mode in ("fusion", "env"):
            feats.append(self.env(num, cat))
        h = self.fuse(torch.cat(feats, dim=1))
        return self.hazard_head(h), self.risk_head(h), attn

    def backbone_params(self):
        return list(self.visual.backbone.parameters()) if hasattr(self, "visual") else []

    def other_params(self):
        bb = {id(p) for p in self.backbone_params()}
        return [p for p in self.parameters() if id(p) not in bb]

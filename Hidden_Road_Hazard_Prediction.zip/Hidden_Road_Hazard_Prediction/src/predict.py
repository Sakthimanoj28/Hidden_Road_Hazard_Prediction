"""Predict from the command line.

  python src/predict.py --image path\\to\\road.jpg --weather rain --rain 12 --visibility 2 --light 0.3
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from PIL import Image
import config
from config import WEATHER, ROAD_TYPES, SEASONS
from inference import load_model, predict, DEFAULT_ENV, get_device


def main():
    d = DEFAULT_ENV
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--mode", default="fusion", choices=["fusion", "vision", "env"])
    ap.add_argument("--weather", default=d["weather"], choices=WEATHER)
    ap.add_argument("--road_type", default=d["road_type"], choices=ROAD_TYPES)
    ap.add_argument("--season", default=d["season"], choices=SEASONS)
    ap.add_argument("--temperature", type=float, default=d["temperature"], help="deg C")
    ap.add_argument("--humidity", type=float, default=d["humidity"], help="percent")
    ap.add_argument("--rain", type=float, default=d["rain"], help="mm/hour")
    ap.add_argument("--visibility", type=float, default=d["visibility"], help="km")
    ap.add_argument("--light", type=float, default=d["light"], help="0 (dark) - 1 (bright)")
    ap.add_argument("--out_dir", default=str(config.OUT_DIR))
    a = ap.parse_args()

    dev = get_device()
    model, ck = load_model(a.mode, a.out_dir, dev)
    env = {k: getattr(a, k) for k in d}
    r = predict(model, ck, Image.open(a.image), env, dev)

    print("\n" + r["message"])
    print(f"Predicted hazard : {r['hazard_label']}  (confidence {r['confidence']:.1%})")
    print(f"Risk level       : {r['risk_level'].upper()}   | risk score {r['risk_score']:.0%}")
    print("Probabilities    :")
    for k, v in sorted(r["probabilities"].items(), key=lambda kv: -kv[1]):
        print(f"   {k:<24}{v:6.1%}")
    if r["attention"] is not None:
        out = Path(a.out_dir) / "predictions"
        out.mkdir(parents=True, exist_ok=True)
        p = out / (Path(a.image).stem + "_attention.png")
        r["attention"].save(p)
        print(f"Attention heat-map saved: {p}")


if __name__ == "__main__":
    main()

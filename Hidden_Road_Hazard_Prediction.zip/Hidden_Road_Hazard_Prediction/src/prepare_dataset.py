"""Copy images from the downloaded public datasets into dataset/<class>/ automatically.

Example (Windows, one line):
  python src/prepare_dataset.py --pothole_dir "D:\\downloads\\pothole" --rscd_dir "D:\\downloads\\RSCD\\train" --debris_dir "D:\\downloads\\debris" --per_class 1000

Rules
  --pothole_dir : any folder tree of pothole photos. Sub-folders named normal / plain /
                  no_pothole / negative are sent to 'no_hazard', everything else to 'pothole'.
  --rscd_dir    : RSCD train folder. ice / snow + wet  -> ice_wet,  water -> waterlogging,
                  dry -> no_hazard.
  --debris_dir  : every image -> debris.
  --normal_dir  : every image -> no_hazard (optional extra clear-road photos).
All arguments are optional - use only the datasets you have. Originals are copied, never moved.
"""
import argparse
import random
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config
from config import IMG_EXT

NEG_WORDS = ("normal", "plain", "no_pothole", "nopothole", "negative", "non_pothole", "non-pothole")


def images_in(folder):
    return [p for p in Path(folder).rglob("*") if p.suffix.lower() in IMG_EXT]


def norm(name):
    return name.lower().replace("_", "-").replace(" ", "-")


def copy_files(files, cls, prefix, dest_root, limit, rng):
    rng.shuffle(files)
    files = files[:limit] if limit else files
    dest = dest_root / cls
    dest.mkdir(parents=True, exist_ok=True)
    for i, f in enumerate(files):
        shutil.copy2(f, dest / f"{prefix}_{i:05d}{f.suffix.lower()}")
    print(f"  {cls:<13} +{len(files):>5} images from {prefix}")
    return len(files)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    ap.add_argument("--pothole_dir")
    ap.add_argument("--rscd_dir")
    ap.add_argument("--debris_dir")
    ap.add_argument("--normal_dir")
    ap.add_argument("--per_class", type=int, default=1000, help="max images taken per source (0 = all)")
    ap.add_argument("--dest", default=str(config.DATA_DIR))
    a = ap.parse_args()
    if not any([a.pothole_dir, a.rscd_dir, a.debris_dir, a.normal_dir]):
        ap.print_help()
        return
    rng, dest, n = random.Random(config.SEED), Path(a.dest), a.per_class
    print("Copying images ...")

    if a.pothole_dir:
        root = Path(a.pothole_dir)
        pos, neg = [], []
        for p in images_in(root):
            rel = [norm(x) for x in p.relative_to(root).parts[:-1]]
            (neg if any(w.replace("_", "-") in part for part in rel for w in NEG_WORDS) else pos).append(p)
        copy_files(pos, "pothole", "pothole", dest, n, rng)
        if neg:
            copy_files(neg, "no_hazard", "plainroad", dest, n, rng)

    if a.rscd_dir:
        ice, wet, water, dry = [], [], [], []
        for d in {p.parent for p in images_in(a.rscd_dir)}:
            name = norm(d.name)
            files = images_in(d)
            if name.startswith(("ice", "fresh-snow", "melted-snow", "snow")):
                ice += files
            elif name.startswith("wet"):
                wet += files
            elif name.startswith("water"):
                water += files
            elif name.startswith("dry"):
                dry += files
        if not (ice or wet or water or dry):
            print("  [warn] no RSCD class folders (ice*/wet*/water*/dry*) found in --rscd_dir")
        half = n // 2 if n else 0
        if ice or wet:
            copy_files(ice, "ice_wet", "rscd_ice", dest, half, rng)
            copy_files(wet, "ice_wet", "rscd_wet", dest, half, rng)
        if water:
            copy_files(water, "waterlogging", "rscd_water", dest, n, rng)
        if dry:
            copy_files(dry, "no_hazard", "rscd_dry", dest, n, rng)

    if a.debris_dir:
        copy_files(images_in(a.debris_dir), "debris", "debris", dest, n, rng)
    if a.normal_dir:
        copy_files(images_in(a.normal_dir), "no_hazard", "normal", dest, n, rng)

    print("\nDone. Now run:  python src/check_dataset.py   (or 2_check_dataset.bat)")


if __name__ == "__main__":
    main()

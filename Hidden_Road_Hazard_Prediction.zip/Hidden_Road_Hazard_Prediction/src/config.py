"""Central settings for the Hidden Road Hazard Prediction project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "dataset"
OUT_DIR = ROOT / "outputs"

SEED = 42
IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}

# Hazard classes = sub-folder names inside dataset/
ALL_CLASSES = ["pothole", "ice_wet", "debris", "waterlogging", "no_hazard"]
CLASS_LABELS = {
    "pothole": "Pothole",
    "ice_wet": "Black ice / wet surface",
    "debris": "Debris",
    "waterlogging": "Waterlogging",
    "no_hazard": "No hazard",
}

RISK_LEVELS = ["low", "medium", "high"]

# Environmental inputs
WEATHER = ["clear", "rain", "fog", "snow", "overcast"]
ROAD_TYPES = ["highway", "urban", "rural"]
SEASONS = ["summer", "monsoon", "autumn", "winter"]
NUM_FEATS = ["temperature", "humidity", "rain", "visibility", "light"]
SEQ_LEN = 6          # number of recent readings fed to the GRU/LSTM

# Hazard severity used to derive the risk level (see README)
SEVERITY = {
    "pothole": 0.70,
    "ice_wet": 0.85,
    "debris": 0.60,
    "waterlogging": 0.75,
    "no_hazard": 0.05,
}

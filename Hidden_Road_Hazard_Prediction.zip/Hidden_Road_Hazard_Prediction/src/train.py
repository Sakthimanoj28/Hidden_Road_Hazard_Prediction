"""Train + evaluate the hazard models.

    python src/train.py                 # trains vision-only, env-only and fusion, then compares
    python src/train.py --mode fusion   # only the proposed fusion model
"""
import argparse
import json
import random
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score, confusion_matrix, classification_report,
                             precision_recall_fscore_support)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config
from config import CLASS_LABELS, RISK_LEVELS
from data_utils import build_tables, split_indices, class_summary
from dataset import HazardDataset, get_transforms
from model import HazardNet


def set_seed(s):
    random.seed(s)
    np.random.seed(s)
    torch.manual_seed(s)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(s)


def run_epoch(model, loader, device, crit_h, crit_r, opt=None, desc=""):
    train = opt is not None
    model.train(train)
    tot_loss, correct, n = 0.0, 0, 0
    ys, ps, rt, rp = [], [], [], []
    with torch.set_grad_enabled(train):
        for b in tqdm(loader, desc=desc, leave=False):
            img, num, cat = b["img"].to(device), b["num"].to(device), b["cat"].to(device)
            y, r = b["y"].to(device), b["risk"].to(device)
            lh, lr_, _ = model(img, num, cat)
            loss = crit_h(lh, y) + 0.5 * crit_r(lr_, r)
            if train:
                opt.zero_grad()
                loss.backward()
                opt.step()
            bs = y.size(0)
            tot_loss += loss.item() * bs
            n += bs
            pred = lh.argmax(1)
            correct += (pred == y).sum().item()
            ys += y.cpu().tolist()
            ps += pred.cpu().tolist()
            rt += r.cpu().tolist()
            rp += lr_.argmax(1).cpu().tolist()
    return {"loss": tot_loss / max(n, 1), "acc": correct / max(n, 1),
            "y": ys, "p": ps, "risk_y": rt, "risk_p": rp}


def plot_curves(hist, path, title):
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].plot(hist["train_loss"], label="train")
    ax[0].plot(hist["val_loss"], label="validation")
    ax[0].set_title("Loss")
    ax[0].set_xlabel("epoch")
    ax[0].legend()
    ax[1].plot(hist["train_acc"], label="train")
    ax[1].plot(hist["val_acc"], label="validation")
    ax[1].set_title("Accuracy")
    ax[1].set_xlabel("epoch")
    ax[1].legend()
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def plot_confusion(cm, names, path, title):
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(names)))
    ax.set_yticks(range(len(names)))
    ax.set_xticklabels(names, rotation=35, ha="right")
    ax.set_yticklabels(names)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title(title)
    thr = cm.max() / 2 if cm.max() else 0
    for i in range(len(names)):
        for j in range(len(names)):
            ax.text(j, i, int(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > thr else "black")
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def train_mode(args, mode, df, X, classes, splits, device, out_root):
    out = out_root / mode
    out.mkdir(parents=True, exist_ok=True)
    tr, va, te = splits
    use_img = mode != "env"
    data_dir = Path(args.data_dir)
    mk = lambda idx, train: HazardDataset(df.iloc[idx], X[idx], data_dir,
                                          get_transforms(args.img_size, train), use_img)
    kw = dict(batch_size=args.batch, num_workers=args.workers, pin_memory=device.type == "cuda")
    train_dl = DataLoader(mk(tr, True), shuffle=True, drop_last=len(tr) > args.batch, **kw)
    val_dl = DataLoader(mk(va, False), shuffle=False, **kw)
    test_dl = DataLoader(mk(te, False), shuffle=False, **kw)

    set_seed(config.SEED)
    model = HazardNet(len(classes), mode, pretrained=not args.no_pretrained, rnn=args.rnn).to(device)

    counts = np.bincount(df.iloc[tr]["label_idx"], minlength=len(classes)).astype(np.float32)
    w = torch.tensor(counts.sum() / (len(classes) * np.maximum(counts, 1)), dtype=torch.float32)
    crit_h = nn.CrossEntropyLoss(weight=w.to(device))     # handles class imbalance
    crit_r = nn.CrossEntropyLoss()

    groups = [{"params": model.other_params(), "lr": args.lr}]
    if model.backbone_params():
        groups.append({"params": model.backbone_params(), "lr": args.lr * 0.1})  # low LR fine-tuning
    opt = torch.optim.Adam(groups)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=2)

    hist = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}
    best, bad, ckpt_path = float("inf"), 0, out / "best.pt"
    print(f"\n=== Training '{mode}' model on {device} "
          f"(train {len(tr)} / val {len(va)} / test {len(te)}) ===")
    t0 = time.time()
    for ep in range(1, args.epochs + 1):
        a = run_epoch(model, train_dl, device, crit_h, crit_r, opt, f"ep{ep} train")
        v = run_epoch(model, val_dl, device, crit_h, crit_r, None, f"ep{ep} val  ")
        sched.step(v["loss"])
        for k, x in (("train_loss", a["loss"]), ("val_loss", v["loss"]),
                     ("train_acc", a["acc"]), ("val_acc", v["acc"])):
            hist[k].append(x)
        print(f"epoch {ep:02d}/{args.epochs} | train loss {a['loss']:.4f} acc {a['acc']:.3f} | "
              f"val loss {v['loss']:.4f} acc {v['acc']:.3f}")
        if v["loss"] < best - 1e-4:
            best, bad = v["loss"], 0
            torch.save({"state_dict": model.state_dict(), "classes": classes, "mode": mode,
                        "img_size": args.img_size, "rnn": args.rnn}, ckpt_path)
        else:
            bad += 1
            if bad >= args.patience:
                print(f"early stopping (no improvement for {args.patience} epochs)")
                break
    mins = (time.time() - t0) / 60

    # ---- test the best checkpoint ----
    model.load_state_dict(torch.load(ckpt_path, map_location=device)["state_dict"])
    t = run_epoch(model, test_dl, device, crit_h, crit_r, None, "test")
    names = [CLASS_LABELS[c] for c in classes]
    labels = list(range(len(classes)))
    p, r, f1, _ = precision_recall_fscore_support(t["y"], t["p"], labels=labels,
                                                  average="macro", zero_division=0)
    cm = confusion_matrix(t["y"], t["p"], labels=labels)
    report = classification_report(t["y"], t["p"], labels=labels, target_names=names,
                                   zero_division=0)
    risk_acc = accuracy_score(t["risk_y"], t["risk_p"])
    metrics = {"mode": mode, "accuracy": accuracy_score(t["y"], t["p"]), "precision": p,
               "recall": r, "f1": f1, "risk_accuracy": risk_acc, "train_minutes": round(mins, 1),
               "epochs_run": len(hist["train_loss"]), "classes": classes,
               "images": class_summary(df, classes)}
    (out / "metrics.json").write_text(json.dumps(metrics, indent=2))
    (out / "history.json").write_text(json.dumps(hist))
    (out / "classification_report.txt").write_text(
        f"Mode: {mode}\n\n{report}\nRisk-level accuracy: {risk_acc:.4f}\n")
    plot_curves(hist, out / "training_curves.png", f"{mode} model")
    plot_confusion(cm, names, out / "confusion_matrix.png", f"Confusion matrix - {mode}")
    print(f"\n--- TEST RESULTS ({mode}) ---\n{report}")
    print(f"accuracy {metrics['accuracy']:.4f} | precision {p:.4f} | recall {r:.4f} | "
          f"F1 {f1:.4f} | risk-level accuracy {risk_acc:.4f}")
    print(f"Saved to: {out}")
    return metrics


def compare(results, out_root):
    df = pd.DataFrame(results)[["mode", "accuracy", "precision", "recall", "f1", "risk_accuracy"]]
    df.to_csv(out_root / "comparison.csv", index=False)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    xs = np.arange(len(df))
    for i, m in enumerate(["accuracy", "precision", "recall", "f1"]):
        ax.bar(xs + i * 0.2 - 0.3, df[m], 0.2, label=m)
    ax.set_xticks(xs)
    ax.set_xticklabels(df["mode"])
    ax.set_ylim(0, 1.05)
    ax.set_title("Vision-only vs Environment-only vs Fusion (test set)")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(out_root / "model_comparison.png", dpi=130)
    plt.close(fig)
    print("\n=== MODEL COMPARISON (test set) ===")
    print(df.round(4).to_string(index=False))
    print(f"\nSaved: {out_root / 'comparison.csv'} and model_comparison.png")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="all", choices=["all", "fusion", "vision", "env"])
    ap.add_argument("--data_dir", default=str(config.DATA_DIR))
    ap.add_argument("--out_dir", default=str(config.OUT_DIR))
    ap.add_argument("--epochs", type=int, default=15)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--img_size", type=int, default=224)
    ap.add_argument("--patience", type=int, default=5)
    ap.add_argument("--workers", type=int, default=0, help="keep 0 on Windows unless you know it works")
    ap.add_argument("--rnn", default="gru", choices=["gru", "lstm"])
    ap.add_argument("--max_per_class", type=int, default=0, help="0 = use all images (lower = faster)")
    ap.add_argument("--no_pretrained", action="store_true", help="do not download ImageNet weights")
    args = ap.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type == "cpu":
        print("[info] No GPU found - training on CPU. For faster runs use e.g. "
              "--max_per_class 600 --img_size 160 --epochs 8")
    set_seed(config.SEED)
    data_dir, out_root = Path(args.data_dir), Path(args.out_dir)
    out_root.mkdir(parents=True, exist_ok=True)

    df, X, classes = build_tables(data_dir)
    if args.max_per_class > 0:
        rs = np.random.RandomState(config.SEED)
        keep = np.sort(np.concatenate([
            rs.permutation(np.where(df["label"].values == c)[0])[:args.max_per_class]
            for c in classes]))
        df, X = df.iloc[keep].reset_index(drop=True), X[keep]
    print("Images per class:", class_summary(df, classes))
    splits = split_indices(df)

    modes = ["vision", "env", "fusion"] if args.mode == "all" else [args.mode]
    results = [train_mode(args, m, df, X, classes, splits, device, out_root) for m in modes]
    if len(results) > 1:
        compare(results, out_root)
    print("\nDONE. Open the 'outputs' folder for graphs, reports and best.pt models.")


if __name__ == "__main__":
    main()

"""Quick pipeline test with FAKE images (takes a few minutes, no download needed).

    python src/smoke_test.py
It creates smoke_data/, trains for 2 epochs and writes to smoke_outputs/. Delete both
folders afterwards. Accuracy here is meaningless - it only proves the code runs.
"""
import subprocess
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
DATA, OUT = ROOT / "smoke_data", ROOT / "smoke_outputs"
CLASSES = ["pothole", "ice_wet", "debris", "waterlogging", "no_hazard"]


def fake(cls, rng):
    base = rng.integers(80, 130)
    im = Image.fromarray(np.clip(rng.normal(base, 12, (128, 128, 3)), 0, 255).astype("uint8"))
    d = ImageDraw.Draw(im)
    if cls == "pothole":
        x, y = rng.integers(30, 90, 2)
        d.ellipse([x, y, x + 30, y + 18], fill=(25, 25, 25))
    elif cls == "ice_wet":
        for _ in range(8):
            x = int(rng.integers(0, 128))
            d.line([x, 0, x + 10, 128], fill=(200, 220, 240), width=2)
    elif cls == "debris":
        for _ in range(6):
            x, y = rng.integers(10, 110, 2)
            d.rectangle([x, y, x + 8, y + 6], fill=tuple(int(v) for v in rng.integers(0, 255, 3)))
    elif cls == "waterlogging":
        d.rectangle([0, 64, 128, 128], fill=(70, 100, 140))
    else:
        d.line([64, 0, 64, 128], fill=(240, 240, 240), width=3)
    return im


def main():
    rng = np.random.default_rng(0)
    for c in CLASSES:
        (DATA / c).mkdir(parents=True, exist_ok=True)
        for i in range(40):
            fake(c, rng).save(DATA / c / f"{c}_{i:03d}.png")
    print("Fake data created. Running a 2-epoch training ...\n")
    cmd = [sys.executable, str(ROOT / "src" / "train.py"), "--data_dir", str(DATA),
           "--out_dir", str(OUT), "--epochs", "2", "--batch", "16", "--img_size", "128",
           "--no_pretrained", "--mode", "all"]
    if subprocess.call(cmd) != 0:
        raise SystemExit("\nSMOKE TEST FAILED - see the error above.")
    print("\nSMOKE TEST PASSED - the pipeline works. Now add your real dataset.")


if __name__ == "__main__":
    main()

# Deep Learning-Based Prediction of Hidden Road Hazards
**CSA4710 – Deep Learning | SIMATS Engineering**
Multimodal model: road image (CNN) + environmental sequence (GRU) → hazard type + risk level.

---

## 1. Quick start (Windows)

1. Extract this zip into `C:\Documents\COURCES\Deep Learning\capestone` (right-click → *Extract All*).
2. Install **Python 3.10 / 3.11 / 3.12** (tick *Add python.exe to PATH*).
3. Double-click **`1_setup.bat`** (installs everything, one time).
4. Double-click **`0_smoke_test.bat`** – proves the whole pipeline runs using fake images. Wait for `SMOKE TEST PASSED`.
5. Download the dataset (section 2) and put it in `dataset\` – or use **`2a_prepare_dataset.bat`**.
6. Double-click **`2_check_dataset.bat`** – shows how many images each class has.
7. Double-click **`3_train.bat`** (or **`3b_train_quick_cpu.bat`** if you have no NVIDIA GPU).
8. Double-click **`4_demo.bat`** – opens the web demo in your browser.

Results (graphs, confusion matrices, reports, trained models) appear in **`outputs\`**.

## 2. Dataset – what to download

Put images in these folders (see `dataset\README.txt` for details):

| Folder | Class | Suggested source |
|---|---|---|
| `dataset\pothole` | Pothole | Kaggle “Pothole Image Dataset” (sachinpatel21) |
| `dataset\ice_wet` | Black ice / wet surface | **RSCD** – classes ice, snow, wet |
| `dataset\waterlogging` | Waterlogging | **RSCD** – class water |
| `dataset\no_hazard` | No hazard | RSCD – class dry, or the “Normal” images of a pothole set |
| `dataset\debris` | Debris | any road-debris / road-obstacle dataset (optional) |

RSCD: <https://github.com/ztsrxh/RSCD-Road_Surface_Classification_Dataset>. Aim for 500–1500 images per class.
Training works with any 2+ classes that have images. The slide-deck datasets BDD100K / Cityscapes can also be cited as related driving datasets.

## 3. Project structure

```
Hidden_Road_Hazard_Prediction/
├── dataset/            <- you add images here (+ environment.csv is auto-created)
├── outputs/            <- results are written here
├── src/
│   ├── config.py           classes, environment features, settings
│   ├── prepare_dataset.py  copies/sorts downloaded datasets into dataset/
│   ├── check_dataset.py    counts images, finds corrupt files
│   ├── env_data.py         environment data + risk-level rule
│   ├── data_utils.py       scanning, labels, 70/15/15 split
│   ├── dataset.py          PyTorch dataset + rain/fog/brightness augmentation
│   ├── model.py            ResNet18+attention | GRU/LSTM | fusion network
│   ├── train.py            training, early stopping, metrics, plots, comparison
│   ├── inference.py        shared prediction code
│   ├── predict.py          command-line prediction
│   ├── app.py              browser demo (Gradio)
│   └── smoke_test.py       fake-data pipeline test
├── *.bat               <- double-click launchers
└── requirements.txt
```

## 4. How it maps to your slides

| Slide | Where in the code |
|---|---|
| Module 1 – data collection & preprocessing | `prepare_dataset.py`, `check_dataset.py`, `data_utils.py`, `dataset.py` (resize, normalise, rotation, brightness, simulated rain & fog, stratified split, class-weighted loss) |
| Module 2 – visual feature extraction | `model.py → VisualBranch` (ResNet18 with ImageNet transfer learning, spatial attention, low-LR fine-tuning) |
| Module 3 – environmental pattern modelling | `model.py → EnvBranch` (GRU over 6 readings of temperature, humidity, rain, visibility, light + embeddings for weather/road/season; `--rnn lstm` switches to LSTM) |
| Module 4 – fusion & prediction | `model.py → HazardNet` (concatenate → FC+ReLU+dropout → softmax hazard head + low/medium/high risk head), `train.py` (cross-entropy, Adam, early stopping, accuracy/precision/recall/F1, confusion matrix, vision-only vs env-only vs fusion comparison), `predict.py`/`app.py` (warning message) |
| System architecture | same flow: image → CNN, weather → GRU → fusion → hazard type + risk |
| Future scope – Grad-CAM/XAI | the attention heat-map saved by `predict.py` / shown in the demo is a first step |

Outputs per model (`outputs\fusion\`, `outputs\vision\`, `outputs\env\`): `best.pt`, `metrics.json`, `classification_report.txt`, `confusion_matrix.png`, `training_curves.png`. Overall: `outputs\comparison.csv`, `outputs\model_comparison.png`.

## 5. Commands (optional, from a terminal in this folder)

```
python src/train.py --mode fusion --epochs 20      # only the fusion model
python src/train.py --max_per_class 600 --img_size 160 --epochs 8   # fast CPU run
python src/predict.py --image C:\path\road.jpg --weather rain --rain 12 --visibility 2 --light 0.3
```

NVIDIA GPU (much faster): the default Windows install of PyTorch is CPU-only. Install a CUDA build, e.g.
`pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121`, then train as usual.

## 6. Important – be clear about this in your report / viva

* **Environmental data is simulated.** No public dataset pairs road-hazard photos with weather sequences, so `dataset\environment.csv` is generated automatically: weather is drawn from class-dependent probabilities (e.g. waterlogging mostly with rain, ice mostly cold) mixed with 35 % random noise, then turned into 6-step sequences. Say so explicitly. Fusion scores partly reflect this assumption, so they show the *method works when context is informative*, not real-world accuracy. If you have real sensor/weather logs, replace `environment.csv` (same columns) and retrain.
* **Risk level labels are rule-based.** Risk = hazard severity × (0.6 + 0.4 × weather adversity from rain, visibility, light, cold), thresholded into low / medium / high (`env_data.py`). The network learns to predict this rule; it is not human-annotated risk.
* Images from different sources look different (RSCD is cropped road patches, pothole sets are dash-cam photos), so a model can partly learn the *source* instead of the hazard. Mention it as a limitation, and prefer balanced numbers per class.
* Cite the datasets you use (RSCD: Zhao et al., IEEE T-ITS 2023; the Kaggle pothole set and its author).

## 7. Troubleshooting

| Problem | Fix |
|---|---|
| `python` not recognised | reinstall Python with *Add to PATH* ticked |
| “Not enough data” | add images to at least 2 class folders, run `2_check_dataset.bat` |
| Could not load ImageNet weights | needs internet on first run; otherwise it trains from scratch (lower accuracy) |
| Out of memory | `python src/train.py --batch 16 --img_size 160` |
| Very slow | use `3b_train_quick_cpu.bat` or `--max_per_class 400` |
| Demo says no trained model | run `3_train.bat` first |
